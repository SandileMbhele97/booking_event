<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Category</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }
        .form-input,
        .form-textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            margin-top: 5px;
        }
        .form-input:focus,
        .form-textarea:focus {
            border-color: #0056b3;
            outline: none;
        }
        .bg-green-500 {
            background-color: #28a745;
        }
        .text-white {
            color: #ffffff;
        }
        .bg-blue-500 {
            background-color: #007bff;
        }
        .text-red-500 {
            color: #dc3545;
        }
        .rounded {
            border-radius: 4px;
        }
        .p-2 {
            padding: 8px;
        }
        .mb-4 {
            margin-bottom: 16px;
        }
        .px-4 {
            padding-left: 16px;
            padding-right: 16px;
        }
        .py-2 {
            padding-top: 8px;
            padding-bottom: 8px;
        }
        .font-medium {
            font-weight: 500;
        }
        .text-sm {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-2xl font-semibold mb-4">Create New Category</h2>

        @if(session('success'))
            <div class="bg-green-500 text-white p-2 mb-4 rounded">
                {{ session('success') }}
            </div>
        @endif

        <form method="POST" action="{{ route('categories.store') }}">
            @csrf

            <div class="mb-4">
                <label for="name" class="block text-sm font-medium text-gray-700">Category Name</label>
                <input type="text" name="name" id="name" class="form-input mt-1 block w-full" value="{{ old('name') }}" required>
                @error('name')
                    <span class="text-red-500 text-sm">{{ $message }}</span>
                @enderror
            </div>

            <div class="mb-4">
                <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                <textarea name="description" id="description" class="form-textarea mt-1 block w-full" rows="4">{{ old('description') }}</textarea>
                @error('description')
                    <span class="text-red-500 text-sm">{{ $message }}</span>
                @enderror
            </div>

            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Create Category</button>
        </form>
    </div>
</body>
</html>
