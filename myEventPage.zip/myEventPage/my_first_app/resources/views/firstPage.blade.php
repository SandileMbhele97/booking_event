@extends('layoutt')
@section('title', 'Home')
@section('content')
    <div class="background-container">
        <div class="home-container">
            <h1>Welcome to Our Event Booking Website</h1>
            <p>Find and book your favorite events easily!</p>
            <div class="button-container">
                <a href="{{ route('login') }}" class="btn btn-login">Login</a>
                <a href="{{ route('registration') }}" class="btn btn-register">Register</a>
            </div>
        </div>
    </div>
@endsection

@section('styles')
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            overflow: hidden;
            background-color: #f4f4f4; /* Fallback background color */
        }

        .background-container {
            position: relative;
            width: 100%;
            height: 100vh;
            background-image: url('{{ asset('images/images.jpg') }}');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .home-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
            z-index: 1; /* Ensure content is on top */
        }

        .home-container h1 {
            margin-bottom: 20px;
            font-size: 3em;
        }

        .home-container p {
            margin-bottom: 30px;
            font-size: 1.5em;
        }

        .button-container {
            display: flex;
            gap: 20px;
            justify-content: center;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            color: #fff;
            text-decoration: none;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }

        .btn-login {
            background-color: #007bff;
        }

        .btn-register {
            background-color: #28a745;
        }

        .btn-login:hover {
            background-color: #0056b3;
        }

        .btn-register:hover {
            background-color: #218838;
        }
    </style>
@endsection
