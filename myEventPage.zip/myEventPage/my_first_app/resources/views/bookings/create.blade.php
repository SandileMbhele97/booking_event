<!-- resources/views/bookings/create.blade.php -->
@extends('layout')

@section('title', 'Book Tickets')

@section('content')
    <main class="booking-page">
        <div class="container">
            <h1>Book Tickets for {{ $event->name }}</h1>
            <div class="event-details">
                <p><strong>Date:</strong> {{ $event->date }}</p>
                <p><strong>Time:</strong> {{ $event->time }}</p>
                <p><strong>Location:</strong> {{ $event->location }}</p>
                <p><strong>Price per Ticket:</strong> ${{ $event->ticket_price }}</p>
            </div>
            
            <form action="{{ route('bookings.store', $event->id) }}" method="POST" id="payment-form">
                @csrf
                <div class="form-group">
                    <label for="number_of_tickets">Number of Tickets</label>
                    <input type="number" id="number_of_tickets" name="number_of_tickets" min="1" required class="form-control" />
                </div>
                
                <div id="card-element">
                    <!-- A Stripe Element will be inserted here. -->
                </div>
                
                <button type="submit" class="btn btn-primary">Pay Now</button>
                
                <input type="hidden" name="stripeToken" id="stripeToken">
            </form>
        </div>
    </main>
    
    <script src="https://js.stripe.com/v3/"></script>
    <script>
        var stripe = Stripe('{{ config('services.stripe.key') }}');
        var elements = stripe.elements();
        
        var card = elements.create('card');
        card.mount('#card-element');
        
        var form = document.getElementById('payment-form');
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            
            stripe.createToken(card).then(function(result) {
                if (result.error) {
                    // Show error in payment form
                    console.error(result.error.message);
                } else {
                    // Insert the token ID into the form so it gets submitted to the server
                    document.getElementById('stripeToken').value = result.token.id;
                    form.submit();
                }
            });
        });
    </script>
@endsection

<style>
    .booking-page {
        padding: 20px;
    }

    .container {
        max-width: 600px;
        margin: 0 auto;
    }

    .event-details {
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .btn-primary {
        background-color: #007bff;
        color: #ffffff;
        padding: 10px 20px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
</style>
