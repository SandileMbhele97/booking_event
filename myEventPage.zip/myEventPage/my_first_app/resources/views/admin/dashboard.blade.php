<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        h2 {
            border-bottom: 2px solid #333;
            padding-bottom: 5px;
            color: #555;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            padding: 8px 0;
            border-bottom: 1px solid #ddd;
        }
        .actions {
            margin-bottom: 20px;
            text-align: right;
        }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            margin-left: 5px;
            border: none;
            border-radius: 4px;
            color: #fff;
            text-decoration: none;
            cursor: pointer;
        }
        .btn-create {
            background-color: #28a745;
        }
        .btn-edit {
            background-color: #ffc107;
        }
        .btn-delete {
            background-color: #dc3545;
        }
        .btn-create:hover {
            background-color: #218838;
        }
        .btn-edit:hover {
            background-color: #e0a800;
        }
        .btn-delete:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Dashboard</h1>
        
        <h2>Users
           
        </h2>
        <ul>
            @foreach ($users as $user)
                <li>
                    {{ $user->name }} ({{ $user->role }})
                    <a href="/users/{{ $user->id }}/edit" class="btn btn-edit">Edit</a>
                    <a href="/users/{{ $user->id }}/delete" class="btn btn-delete">Delete</a>
                </li>
            @endforeach
        </ul>

        <h2>Events
           
        </h2>
        <ul>
            @foreach ($events as $event)
                <li>
                    {{ $event->name }} - {{ $event->date }}
                    <a href="/events/{{ $event->id }}/edit" class="btn btn-edit">Edit</a>
                    <a href="/events/{{ $event->id }}/delete" class="btn btn-delete">Delete</a>
                </li>
            @endforeach
        </ul>

        <h2>Categories
            <span class="actions">
                <a href="{{ route('categories.create') }}" class="btn btn-create">Add Category</a>
            </span>
        </h2>
        <ul>
            @foreach ($categories as $category)
                <li class="mb-4 flex items-center justify-between">
                    <div>
                        {{ $category->name }} - {{ $category->description }}
                    </div>
                    <form action="{{ route('categories.destroy', $category->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                    </form>
                </li>
            @endforeach
        </ul>
    </div>
</body>
</html>
