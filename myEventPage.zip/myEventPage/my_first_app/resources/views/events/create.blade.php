@extends('layout')
@section('title', 'Home')
@section('content')
    <div class="container mx-auto p-4 flex items-center justify-center min-h-screen">
        <div class="form-container w-full max-w-lg p-6 bg-white rounded-lg shadow-md">
            @if(session('success'))
                <div class="bg-green-500 text-white p-2 mb-4 rounded">
                    {{ session('success') }}
                </div>
            @endif

            <form method="POST" action="{{ route('events.store') }}" enctype="multipart/form-data">
                @csrf
                <h2 class="text-2xl font-semibold mb-4">Create New Event</h2>
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">Event Name</label>
                    <input type="text" name="name" id="name" class="form-input mt-1 block w-full" value="{{ old('name') }}" required>
                    @error('name')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-700">Event Description</label>
                    <textarea name="description" id="description" class="form-textarea mt-1 block w-full" rows="4">{{ old('description') }}</textarea>
                    @error('description')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="location" class="block text-sm font-medium text-gray-700">Location</label>
                    <input type="text" name="location" id="location" class="form-input mt-1 block w-full" value="{{ old('location') }}" required>
                    @error('location')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="date" class="block text-sm font-medium text-gray-700">Event Date</label>
                    <input type="date" name="date" id="date" class="form-input mt-1 block w-full" value="{{ old('date') }}" required>
                    @error('date')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="time" class="block text-sm font-medium text-gray-700">Event Time</label>
                    <input type="time" name="time" id="time" class="form-input mt-1 block w-full" value="{{ old('time') }}" required>
                    @error('time')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="category_id" class="block text-sm font-medium text-gray-700">Category</label>
                    <select name="category_id" id="category_id" class="form-select mt-1 block w-full" required>
                        <option value="">Select Category</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                                {{ $category->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('category_id')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="max_attendees" class="block text-sm font-medium text-gray-700">Max Attendees</label>
                    <input type="number" name="max_attendees" id="max_attendees" class="form-input mt-1 block w-full" value="{{ old('max_attendees') }}" required>
                    @error('max_attendees')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="ticket_price" class="block text-sm font-medium text-gray-700">Ticket Price</label>
                    <input type="number" name="ticket_price" id="ticket_price" class="form-input mt-1 block w-full" step="0.01" value="{{ old('ticket_price') }}" required>
                    @error('ticket_price')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="status" class="block text-sm font-medium text-gray-700">Event Status</label>
                    <select name="status" id="status" class="form-select mt-1 block w-full" required>
                        <option value="">Select Status</option>
                        <option value="upcoming" {{ old('status') == 'upcoming' ? 'selected' : '' }}>Upcoming</option>
                        <option value="ongoing" {{ old('status') == 'ongoing' ? 'selected' : '' }}>Ongoing</option>
                        <option value="completed" {{ old('status') == 'completed' ? 'selected' : '' }}>Completed</option>
                    </select>
                    @error('status')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="visibility" class="block text-sm font-medium text-gray-700">Visibility</label>
                    <select name="visibility" id="visibility" class="form-select mt-1 block w-full" required>
                        <option value="">Select Visibility</option>
                        <option value="public" {{ old('visibility') == 'public' ? 'selected' : '' }}>Public</option>
                        <option value="private" {{ old('visibility') == 'private' ? 'selected' : '' }}>Private</option>
                    </select>
                    @error('visibility')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="image" class="block text-sm font-medium text-gray-700">Event Image</label>
                    <input type="file" name="image" id="image" class="form-input mt-1 block w-full">
                </div>

                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Create Event</button>
            </form>
        </div>
    </div>
@endsection

<style>
    body {
        font-family: 'Helvetica Neue', Arial, sans-serif;
        background-color: #e9ecef;
        margin: 0;
        padding: 0;
    }

    .container {
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .form-container {
        background-color: #f8f9fa;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        width: 100%;
    }

    .form-input, .form-textarea, .form-select {
        border-radius: 5px;
        border: 1px solid #ced4da;
        padding: 10px;
        width: 100%;
    }

    .btn-primary {
        background-color: #007bff;
        border: none;
        padding: 10px;
        border-radius: 5px;
        transition: background-color 0.3s ease-in-out;
        width: 100%;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
</style>
