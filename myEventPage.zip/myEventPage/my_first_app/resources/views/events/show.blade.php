<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $event->name }}</title>
    <style>
        .img-fluid {
            max-width: 100%;
            height: auto;
        }
        .event-details {
            padding: 20px;
            max-width: 800px;
            margin: auto;
        }
    </style>
</head>
<body>
    <div class="event-details">
        <h1>{{ $event->name }}</h1>
        
        @if($event->image)
            <img src="{{ Storage::url('events/' . $event->image) }}" alt="{{ $event->name }}" class="img-fluid">
        @endif

        <p><strong>Description:</strong> {{ $event->description }}</p>
        <p><strong>Date:</strong> {{ $event->date }}</p>
        <p><strong>Time:</strong> {{ $event->time }}</p>
        <p><strong>Location:</strong> {{ $event->location }}</p>
        <p><strong>Category:</strong> {{ $event->category->name ?? 'N/A' }}</p>
        <p><strong>Organizer:</strong> {{ $event->organizer->name ?? 'N/A' }}</p>
        <p><strong>Price:</strong> ${{ $event->ticket_price }}</p>
        <p><strong>Status:</strong> {{ $event->status }}</p>
        <p><strong>Visibility:</strong> {{ $event->visibility }}</p>

        <!-- Add booking functionality here if needed -->
        <a href="{{ route('events.index') }}">Back to Events</a>
    </div>
</body>
</html>
