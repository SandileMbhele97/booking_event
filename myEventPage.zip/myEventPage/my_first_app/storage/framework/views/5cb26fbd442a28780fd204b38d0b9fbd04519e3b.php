<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid" style="background-color: blueviolet;">
    <a class="navbar-brand" href="#">Online Booking</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
        </li>

        <!-- User Authentication Section -->

        <?php if(auth()->guard()->guest()): ?>

        <li class="nav-item">
          <a class="nav-link active" aria-current="page"href="<?php echo e(route('registration')); ?>">Register</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('login')); ?>">Login</a>
        </li>
       
        <?php else: ?>
        <!-- <p class="mb-4 text-gray-700"><b></b></p> <li class="nav-item"> -->
        <li class="nav-item">
          <a class="nav-link active" aria-current="page"><?php echo e(Auth::user()->name); ?>.</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('logout')); ?>">Logout</a>
        </li>
       
      
        <?php endif; ?>



        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown link
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<style>
  /* Ensure that the navbar covers the top part of the page */
  .navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000;
    /* Ensure the navbar stays on top of other content */
    background-color: blueviolet;
    /* Background color for the navbar */
  }

  /* Add padding to the body to account for the fixed navbar */
  body {
    padding-top: 90px;
    /* Adjust this value based on the height of your navbar */
  }

  .navbar-brand {
    color: #fff !important;
    /* White color for the brand name */
    font-weight: bold;
    /* Make the brand name bold */
  }

  .navbar-brand:hover {
    color: #f0f0f0 !important;
    /* Slightly lighter color on hover */
  }

  .nav-link {
    color: #fff !important;
    /* White color for the links */
    font-weight: 500;
    /* Slightly bolder font for links */
  }

  .nav-link:hover {
    color: #e0e0e0 !important;
    /* Slightly lighter color on hover */
  }

  .navbar-toggler-icon {
    background-image: url('data:image/svg+xml;charset=utf8,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30"%3E%3Cpath stroke="rgba(255,255,255,.5)" stroke-width="2" d="M5 8h20M5 15h20M5 22h20"/%3E%3C/svg%3E');
    /* Custom color for the toggler icon */
  }

  .navbar-nav {
    margin-left: auto;
    /* Align nav items to the right */
  }

  .nav-item {
    margin-left: 1rem;
    /* Space between nav items */
  }

  .nav-item.dropdown .dropdown-menu {
    background-color: blueviolet;
    /* Background color for dropdown menu */
    border: none;
    /* Remove border from dropdown menu */
  }

  .dropdown-item {
    color: #fff;
    /* White color for dropdown items */
  }

  .dropdown-item:hover {
    background-color: #6a1b9a;
    /* Slightly darker background on hover */
    color: #fff;
    /* Ensure text stays white on hover */
  }

  .dropdown-toggle::after {
    color: #fff;
    /* White color for the dropdown arrow */
  }
</style><?php /**PATH C:\Users\USER\Desktop\htdocs\myEventPage\my_first_app\resources\views/include/header.blade.php ENDPATH**/ ?>