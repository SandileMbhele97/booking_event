
<?php $__env->startSection('title', 'Events'); ?>
<?php $__env->startSection('content'); ?>
    <main class="event-page">
        <h1 class="text-center">Upcoming Events</h1>
        <div class="event-container">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <?php if($event->image): ?>
                        <img src="<?php echo e(Storage::url('public/events/' . $event->image)); ?>" alt="<?php echo e($event->name); ?>" class="event-image">
                    <?php endif; ?>
                    <h2><?php echo e($event->name); ?></h2>
                    <p><?php echo e($event->description); ?></p>
                    <p>Date: <?php echo e($event->date); ?> Time: <?php echo e($event->time); ?></p>
                    <p>Location: <?php echo e($event->location); ?></p>
                    <p>Price: $<?php echo e($event->ticket_price); ?></p>
                    <a href="<?php echo e(route('events.show', $event->id)); ?>" class="btn">View Details</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
    <footer class="footer">
        <p>&copy; <?php echo e(date('Y')); ?> Event Booking Platform. All rights reserved.</p>
    </footer>
<?php $__env->stopSection(); ?>

<style>
    body {
        font-family: 'Helvetica Neue', Arial, sans-serif;
        background-color: #e9ecef;
        margin: 0;
        padding: 0;
    }

    .event-page {
        padding: 20px;
    }

    .text-center {
        text-align: center;
    }

    .event-container {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
    }

    .card {
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 20px;
        width: calc(50% - 20px); /* Two columns with gap */
        box-sizing: border-box;
        text-align: center;
    }

    .card h2 {
        font-size: 1.5rem;
        margin-bottom: 10px;
    }

    .card p {
        margin-bottom: 10px;
        color: #333;
    }

    .event-image {
        width: 100%;
        height: auto;
        border-radius: 10px;
        margin-bottom: 10px;
    }

    .btn {
        display: inline-block;
        background-color: #007bff;
        color: #ffffff;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #0056b3;
    }

    .footer {
        text-align: center;
        padding: 10px;
        background-color: #ffffff;
        box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1);
        position: relative;
        bottom: 0;
        width: 100%;
    }
</style>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\htdocs\myEventPage\my_first_app\resources\views/events/index.blade.php ENDPATH**/ ?>