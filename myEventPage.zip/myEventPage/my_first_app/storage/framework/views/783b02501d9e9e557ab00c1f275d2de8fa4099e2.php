
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

<div class="container mx-auto p-6">
    <h1 class="text-4xl font-extrabold text-gray-900 mb-6">Welcome to Event Booking System</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-4 mb-6 rounded shadow-md">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <!-- Events Section -->
        <div class="bg-white p-6 shadow-lg rounded-lg">
            <h2 class="text-2xl font-semibold mb-4">Events</h2>
            <p class="mb-4 text-gray-700">Manage and view all upcoming and past events.</p>
            <a href="<?php echo e(route('events.index')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">View Events</a>
        </div>

        <!-- Create Event Section -->
        <div class="bg-white p-6 shadow-lg rounded-lg">
            <h2 class="text-2xl font-semibold mb-4">Create Event</h2>
            <p class="mb-4 text-gray-700">Create a new event for your upcoming activities.</p>
            <a href="<?php echo e(route('events.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">Create Event</a>
        </div>

        <!-- Categories Section -->
        <div class="bg-white p-6 shadow-lg rounded-lg">
            <h2 class="text-2xl font-semibold mb-4">Categories</h2>
            <p class="mb-4 text-gray-700">View and manage event categories.</p>
            <a href="<?php echo e(route('categories.index')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">View Categories</a>
        </div>
    </div>
</div>

<!-- About Section -->
<section class="about-section bg-gray-100 py-8">
    <div class="container mx-auto text-center">
        <h2 class="text-3xl font-semibold mb-4">About Us</h2>
        <p class="text-gray-700 mb-4">Learn more about our mission and values. We are dedicated to providing a platform for seamless event booking and management.</p>
    </div>
</section>

<!-- Contact Us Section -->
<section class="contact-section bg-white py-8">
    <div class="container mx-auto text-center">
        <h2 class="text-3xl font-semibold mb-4">Contact Us</h2>
        <p class="text-gray-700 mb-4">Have questions or need support? Reach out to us via email at <a href="mailto:support@example.com" class="text-blue-600 hover:underline">support@example.com</a> or call us at (123) 456-7890.</p>
    </div>
</section>

<?php $__env->stopSection(); ?>
<style>
    body {
        font-family: 'Helvetica Neue', Arial, sans-serif;
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
    }

    .container {
        padding: 20px;
        max-width: 1200px;
        margin: auto;
    }

    .text-center {
        text-align: center;
    }

    .bg-white {
        background-color: #ffffff;
    }

    .bg-gray-100 {
        background-color: #f1f5f9;
    }

    .text-gray-900 {
        color: #111827;
    }

    .text-gray-700 {
        color: #374151;
    }

    .bg-green-500 {
        background-color: #10b981;
    }

    .bg-blue-600 {
        background-color: #2563eb;
    }

    .bg-blue-700 {
        background-color: #1d4ed8;
    }

    .bg-green-600 {
        background-color: #059669;
    }

    .bg-green-700 {
        background-color: #047857;
    }

    .text-white {
        color: #ffffff;
    }

    .hover\:bg-blue-700:hover {
        background-color: #1d4ed8;
    }

    .hover\:bg-green-700:hover {
        background-color: #047857;
    }

    .transition {
        transition: background-color 0.3s;
    }

    .shadow-lg {
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .rounded-lg {
        border-radius: 8px;
    }

    .rounded {
        border-radius: 4px;
    }

    .py-8 {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }

    .mb-6 {
        margin-bottom: 1.5rem;
    }

    .mb-4 {
        margin-bottom: 1rem;
    }

    .p-6 {
        padding: 1.5rem;
    }

    .grid {
        display: grid;
    }

    .grid-cols-1 {
        grid-template-columns: repeat(1, minmax(0, 1fr));
    }

    .sm\:grid-cols-2 {
        @media (min-width: 640px) {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }

    .lg\:grid-cols-3 {
        @media (min-width: 1024px) {
            grid-template-columns: repeat(3, minmax(0, 1fr));
        }
    }

    .gap-6 {
        gap: 1.5rem;
    }

    .bg-gray-100 {
        background-color: #f1f5f9;
    }

    .py-8 {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }
</style>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\htdocs\myEventPage\my_first_app\resources\views/home.blade.php ENDPATH**/ ?>