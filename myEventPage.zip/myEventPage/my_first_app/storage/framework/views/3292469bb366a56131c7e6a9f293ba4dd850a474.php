<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> | Event Booking</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <header>
        <nav>
            <a href="<?php echo e(url('/')); ?>">Home</a>
            <!-- You can add more navigation links here -->
        </nav>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <p>&copy; <?php echo e(date('Y')); ?> Event Booking. All rights reserved.</p>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\USER\Desktop\htdocs\myEventPage\my_first_app\resources\views/layoutt.blade.php ENDPATH**/ ?>