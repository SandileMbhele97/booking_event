<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($event->name); ?></title>
    <style>
        .img-fluid {
            max-width: 100%;
            height: auto;
        }
        .event-details {
            padding: 20px;
            max-width: 800px;
            margin: auto;
        }
    </style>
</head>
<body>
    <div class="event-details">
        <h1><?php echo e($event->name); ?></h1>
        
        <?php if($event->image): ?>
            <img src="<?php echo e(Storage::url('events/' . $event->image)); ?>" alt="<?php echo e($event->name); ?>" class="img-fluid">
        <?php endif; ?>

        <p><strong>Description:</strong> <?php echo e($event->description); ?></p>
        <p><strong>Date:</strong> <?php echo e($event->date); ?></p>
        <p><strong>Time:</strong> <?php echo e($event->time); ?></p>
        <p><strong>Location:</strong> <?php echo e($event->location); ?></p>
        <p><strong>Category:</strong> <?php echo e($event->category->name ?? 'N/A'); ?></p>
        <p><strong>Organizer:</strong> <?php echo e($event->organizer->name ?? 'N/A'); ?></p>
        <p><strong>Price:</strong> $<?php echo e($event->ticket_price); ?></p>
        <p><strong>Status:</strong> <?php echo e($event->status); ?></p>
        <p><strong>Visibility:</strong> <?php echo e($event->visibility); ?></p>

        <!-- Add booking functionality here if needed -->
        <a href="<?php echo e(route('events.index')); ?>">Back to Events</a>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myEventPage\my_first_app\resources\views/events/show.blade.php ENDPATH**/ ?>