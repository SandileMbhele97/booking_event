
<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1>Admin Dashboard</h1>
        
        <h2>Users
           
        </h2>
        <ul>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($user->name); ?> (<?php echo e($user->role); ?>)
                    <a href="/users/<?php echo e($user->id); ?>/edit" class="btn btn-edit">Edit</a>
                   
                    <form action="<?php echo e(route('users.destroyUser',$user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-delete">Delete</button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <h2>Events
           
        </h2>
        <ul>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($event->name); ?> - <?php echo e($event->date); ?>

                    <a href="/events/<?php echo e($event->id); ?>/edit" class="btn btn-edit">Edit</a>
                 
                    <form action="<?php echo e(route('events.destroy',$event->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-delete">Delete</button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <h2>Categories
            <span class="actions">
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-create">Add Category</a>
            </span>
        </h2>
        <ul>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="mb-4 flex items-center justify-between">
                    <div>
                        <?php echo e($category->name); ?> - <?php echo e($category->description); ?>

                    </div>
                    <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-delete">Delete</button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <?php $__env->stopSection(); ?>
    <style>
     body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

.container {
    width: 80%;
    margin: 20px auto;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
}

h2 {
    border-bottom: 2px solid #333;
    padding-bottom: 10px;
    color: #555;
    margin-bottom: 15px;
}

ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

li {
    padding: 10px 0;
    border-bottom: 1px solid #ddd;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

li:last-child {
    border-bottom: none;
}

.actions {
    margin-bottom: 20px;
    text-align: right;
}

.btn {
    display: inline-block;
    padding: 8px 16px;
    margin-left: 5px;
    border: none;
    border-radius: 4px;
    color: #fff;
    text-decoration: none;
    cursor: pointer;
    font-size: 14px;
    transition: background-color 0.3s, transform 0.2s;
}

.btn-create {
    background-color: #28a745;
}

.btn-edit {
    background-color: #ffc107;
}

.btn-delete {
    background-color: #c82333;
}

.btn-create:hover {
    background-color: #218838;
    transform: scale(1.05);
}

.btn-edit:hover {
    background-color: #e0a800;
    transform: scale(1.05);
}

.btn-delete:hover {
    background-color: #c82333;
    transform: scale(1.05);
}

    </style>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\htdocs\myEventPage\my_first_app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>