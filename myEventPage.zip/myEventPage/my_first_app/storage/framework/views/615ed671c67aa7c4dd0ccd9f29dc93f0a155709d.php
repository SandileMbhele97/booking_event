
<?php $__env->startSection('title','Registration'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="mt-5">
        <?php if($errors->any()): ?>
        <div>
            <?php $__currentLoopData = $errors-> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php if(session()->has('error')): ?>

        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

        <?php endif; ?>

        <?php if(session()->has('success')): ?>

        <div class="alert alert-success"><?php echo e(session('success')); ?></div>

        <?php endif; ?>
    </div>

    
    <div class="myform" style="background-color: blueviolet; border-radius: 10%; width: 50%;">
    
<form action="<?php echo e(route('registration.post')); ?>" method="post" style="margin-bottom: auto; margin-right:auto; width: 50;">
    <?php echo csrf_field(); ?>

    <h1>Registration Form</h1>
  <div class="mb-3">
    <label  class="form-label">Full Name</label>
    <input type="text" style="width: 500px;" class="form-control" name="name">
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" style="width: 500px;" class="form-control" name="email" >
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" style="width: 500px;" class="form-control" name="password">
  </div>
  <div class="mb-3">
    <label  class="form-label">Role</label>
   <select name="role">
      <option value="Admin">Admin</option>
      <option value="Organizer">Organizer</option>
      <option value="User">User/Attender</option>
   </select>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<style>
    body {
        font-family: 'Helvetica Neue', Arial, sans-serif;
        background-color: #e9ecef;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    form {
        background-color: #f8f9fa;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .form-label {
        font-weight: bold;
    }

    .form-control {
        border-radius: 5px;
        border: 1px solid #ced4da;
        padding: 10px;
    }

    .form-check-label {
        margin-left: 5px;
    }

    .btn-primary {
        background-color: #007bff;
        border: none;
        padding: 10px;
        border-radius: 5px;
        transition: background-color 0.3s ease-in-out;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }

    .text-center {
        text-align: center;
    }
</style>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\myEventPage\my_first_app\resources\views/registration.blade.php ENDPATH**/ ?>