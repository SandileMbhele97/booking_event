<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Event;
use App\Models\Category;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        $users = User::all();
        $events = Event::all();
        $categories = Category::all();
        return view('admin.dashboard', compact('users', 'events', 'categories'));
    }
    
    public function manageEvents()
    {
        $events = Event::all();
        return view('admin.manage-events', compact('events'));
    }

    public function manageUsers()
    {
        $users = User::all();
        return view('admin.manage-users', compact('users'));
    }
}
