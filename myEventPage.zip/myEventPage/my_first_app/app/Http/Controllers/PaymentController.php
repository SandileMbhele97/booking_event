<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function show($bookingId)
    {
        $booking = Booking::findOrFail($bookingId);
        // Show payment form
        return view('payment.show', compact('booking'));
    }

    public function process(Request $request, $bookingId)
    {
        $booking = Booking::findOrFail($bookingId);
        
        // Process payment (e.g., with Stripe API)
        
        // Update booking payment status
        $booking->update(['payment_status' => 'completed']);
        
        return redirect()->route('booking.history')->with('success', 'Payment successful!');
    }
}
