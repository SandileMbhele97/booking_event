<?php

namespace App\Http\Controllers;
use App\Models\Booking;
use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    public function store(Request $request, $eventId)
    {
        $event = Event::findOrFail($eventId);
        
        // Validate booking request
        $request->validate([
            'quantity' => 'required|integer|min:1',
        ]);

        // Create booking
        $booking = Booking::create([
            'user_id' => Auth::id(),
            'event_id' => $eventId,
            'payment_status' => 'pending',
            'qr_code' => '', // Generate QR code here
        ]);

        // Redirect to payment
        return redirect()->route('payment.show', ['booking' => $booking->id]);
    }
    
    public function history()
    {
        $bookings = Booking::where('user_id', Auth::id())->get();
        return view('bookings.history', compact('bookings'));
    }
}
